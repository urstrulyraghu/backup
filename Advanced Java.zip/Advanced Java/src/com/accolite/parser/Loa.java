package com.accolite.parser;

public class Loa {
	String loa_Issue_Date;
	String loa_Name;
	String loa_Status;
}
